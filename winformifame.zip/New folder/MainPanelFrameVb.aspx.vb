﻿
Partial Class MainPanelFrameVb
    Inherits System.Web.UI.Page
#Region "Notification Link Button Event Handler"
    ''' <summary>
    ''' Notification link button all click event handler
    ''' Used to bring up equipment all link page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>

        Protected Sub lnkAll_Click(sender As Object, e As EventArgs) Handles lnkAll.Click
        'Response.Redirect("~/Manage/ManageLists.aspx?Id=All")
    End Sub

    ''' <summary>
    ''' Notification link button equipment click event handler
    ''' Used to bring up equipment type link page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub lnkEquipment_Click(sender As Object, e As EventArgs) Handles lnkEquipment.Click
        'Response.Redirect("~/Manage/ManageLists.aspx?Id=Equipment")
    End Sub

    ''' <summary>
    ''' Notification link button family click event handler
    ''' Used to bring up equipment family link page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub lnkFamily_Click(sender As Object, e As EventArgs) Handles lnkFamily.Click
        'Response.Redirect("~/Manage/ManageLists.aspx?Id=Family")
    End Sub



    ''' <summary>
    ''' Notification link button type click event handler
    ''' Used to bring up notification type link page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub lnkType_Click(sender As Object, e As EventArgs) Handles lnkType.Click
        'Response.Redirect("~/Manage/ManageLists.aspx?Id=Type")
    End Sub
#End Region

    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs) Handles LinkButton1.Click
        'Dim sb As System.Text.StringBuilder = New System.Text.StringBuilder()
        'sb.Append("<script language='javascript'>")
        'sb.Append("var lbl = document.getElementById('lblDisplayDate');")
        'sb.Append("lbl.style.color='red';")
        'sb.Append("</script>")
        'If Not ClientScript.IsClientScriptBlockRegistered("JSScriptBlock") Then
        '    ClientScript.RegisterClientScriptBlock(Me.[GetType](), "redirect", sb.ToString())
        'End If
        ''Dim  transactionNumber =""
        ''Page.ClientScript.RegisterStartupScript("redirect", "&lt;Script language = 'Javascript'> window.parent.location='~/Sales/OrderCheckedOut.aspx?ObjectID=" + transactionNumber + "' ; </Script>")
        ''Response.Redirect("~/MainScreen.aspx")
        'ClientScript.RegisterClientScriptBlock((Me.[GetType](), "RedirectScript", "window.parent.location = '~/MainScreen.aspx'", true)
        'ClientScript.RegisterClientScriptBlock(Me.[GetType](), "redirect", "window.parent.location = 'http://localhost:13554/MainScreen.aspx'")
        'If Not ClientScript.IsClientScriptBlockRegistered("redirect") Then
        '    ClientScript.RegisterClientScriptBlock(Me.[GetType](), "redirect", "window.parent.location = 'http://localhost:13554/MainScreen.aspx'")
        'End If
        'string url = "https://siteurl.com";
        'Response.Write("<script>top.location='"+url+"';parent.location='"+url+"';</script>");


        'ClientScript.RegisterStartupScript(Me.[GetType](), "redirect", "if(top!=self) {top.location.href = 'http://localhost:13554/MainScreen.aspx';}", True)
        Dim url As String = "http://localhost:13554/MainScreen.aspx"
    '    Response.Write("<script>top.location='" & url & "';parent.location='" & url & "';</script>")

        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "Redirect", "window.parent.location='" & url & "';", True)
        UpdatePanel1.Update()
    End Sub
End Class
