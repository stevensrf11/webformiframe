﻿Imports System.Drawing
Imports System.Web.Services

Partial Class MainMasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

      

        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(Now.AddSeconds(-1))
        Response.Cache.SetNoStore()
        Response.AppendHeader("Pragma", "no-cache")

        Dim bc As HttpBrowserCapabilities
        Dim s As String = ""
        bc = Request.Browser

        With bc
            s = .Browser
            s &= "  " & .Version
        End With

        lblVersion.Text = ConfigurationManager.AppSettings("VersionInformation") & " ( " & s & " )"


        'If Not IsPostBack Then
        '    If Session("EM_Admin") < 1 Then
        '        MasterMenu.Panes("AccordionPane0").Visible = False
        '    Else
        '        MasterMenu.Panes("AccordionPane0").Enabled = True
        '    End If
        'End If

            Page.Title = "Equipment Manager"

    End Sub





    ''' <summary>
    ''' Sets a link button text color
    ''' </summary>
    ''' <param name="panelInex">Pane index number</param>
    ''' <param name="lnkButtonId">Name of link button identificaiton</param>
    ''' <param name="textColor">Text color</param>
    ''' <remarks>Calling FindControl on the link button id string always returned nothing.</remarks>
    Public Sub SetLinkButtobFontColor(ByVal panelInex As Int32, ByVal lnkButtonId As String, ByVal textColor As Color)

        'Select Case lnkButtonId
        '    Case "lnkAll"
        '        lnkAll.ForeColor = textColor
        '    Case "lnkEquipment"
        '        lnkEquipment.ForeColor = textColor
        '    Case "lnkFamily"
        '        lnkFamily.ForeColor = textColor
        '    Case "lnkType"
        '        lnkType.ForeColor = textColor
        'End Select

    End Sub
End Class

