﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MainPanelFrame : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //javascript:window.parent.location.href = ../MainScreen.aspx'
    //    LinkButton1.OnClientClick = "coolRedirect('http://localhost:13554/MainScreen.aspx');return false;";
    }

    protected void lnkManageLists_OnClick(object sender, EventArgs e)
    {
    }

    protected void lnkAll_OnClick(object sender, EventArgs e)
    {
    }

    protected void lnkFamily_OnClick(object sender, EventArgs e)
    {
    }

    protected void lnkType_OnClick(object sender, EventArgs e)
    {
    }

    protected void LinkButton1_OnClick(object sender, EventArgs e)
    {
        try
        {
        string url = "http://localhost:13554/MainScreen.aspx";
            //Response.Clear();
            //Response.Write("<script>top.location='" + url + "';parent.location='" + url + "';</script>");
            //ClientScriptManager.RegisterClientScriptBlock(this.GetType(),
            //    "RedirectScript", "window.parent.location = 'http://localhost:13554/MainScreen.aspx'", true);
            // ClientScript.RegisterStartupScript(this.GetType(), "redirect", "if(top!=self) {top.location.href = 'http://localhost:13554/MainScreen.aspx';}", true);
            //          Response.Write("<script>window.open('http://localhost:13554/MainScreen.aspx','_parent');</script>");
            //Response.Write("<script>window.open('MainScreen.aspx.aspx','_parent');</script>");
            UpdatePanel1.Update();

        }
        catch (Exception exception)
        {
            Console.WriteLine(exception);
            throw;
        }
    }

    protected void LinkButton2_OnClick(object sender, EventArgs e)
    {
        
    }
}