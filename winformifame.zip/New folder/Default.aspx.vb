﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load




                Response.Redirect("~/Views/wbformvb.aspx", True)
 
    End Sub
End Class
