﻿
Partial Class Manage_ManageLists
    Inherits System.Web.UI.Page

End Class
