﻿
Partial Class Webformvb
    Inherits System.Web.UI.Page

End Class
